from zamba.cli import app

app(prog_name="python -m zamba")
