from .densepose_manager import DensePoseManager, MODELS  # noqa
from .config import DensePoseConfig, DensePoseOutputEnum  # noqa
